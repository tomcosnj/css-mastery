$(document).ready(function(){
    
    // FORMS
    $("input[type='button']").addClass('button');
    $("input[type='checkbox']").addClass('checkbox');
    $("input[type='file']").addClass('file');
    $("input[type='image']").addClass('image');
    $("input[type='password']").addClass('password');
    $("input[type='radio']").addClass('radio');
    $("input[type='submit']").addClass('submit');
    $("input[type='text']").addClass('text');
    
    $("div#others_routes ul li:first").addClass('first');
    $("div#others_routes ul li:last").addClass('last');
    
});